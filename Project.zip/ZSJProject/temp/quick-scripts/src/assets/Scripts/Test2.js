"use strict";
cc._RF.push(module, '32339/oKb9AII7J3yoVJFI8', 'Test2');
// Scripts/Test2.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Test2 = /** @class */ (function (_super) {
    __extends(Test2, _super);
    function Test2() {
        //这是一条注释
        //private -- 私有变量 public -- 公有变量  
        //区别就是私有变量只能在类内访问，共有变量可以在类外访问
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //这是一个数值的声明语句  typeScript 没有区分整型和浮点型统一用number来声明
        _this.a_number = 0;
        //这是一个字符串的声明语句
        _this.a_string = "";
        //这是一个布尔参数的声明语句
        _this.a_bool = true;
        //这是一个数组的声明语句
        _this.a_Array = new Array();
        _this.b_number = 0;
        _this.b_string = "";
        _this.b_bool = true;
        _this.b_Array = new Array();
        return _this;
        //关键字 var let const 
        //      break return continue
        //      for
        //      if else 
    }
    /**名称为Func1的无返回值的私有函数 */
    Test2.prototype.Func1 = function () {
    };
    /**名称为Func2的无返回值的共有函数 */
    Test2.prototype.Func2 = function () {
    };
    /**名称为Func3的无返回值的共有函数 */
    Test2.Func3 = function () {
    };
    /**名称为Func4的无返回值的共有函数
     * 在调用这个函数的时候需要传入两个参数 -- arg1,arg2
     * 这两个参数必须是数值类型
    */
    Test2.prototype.Func4 = function (arg1, arg2) {
    };
    /**名称为Func5的返回值是数值型的共有函数
     * 在调用这个函数的时候需要传入两个参数 -- arg1,arg2
     * 这两个参数必须是数值类型
    */
    Test2.prototype.Func5 = function (arg1, arg2) {
        //let 是在函数内部声明参数是用到的关键字 
        var sum = 0;
        //sum 的结果是arg1和arg2的和
        sum = arg1 + arg2;
        //返回的关键字
        return sum;
    };
    /**
     * 在调用这个函数的时候需要传入一个参数 -- arg1
     * 这个参数必须是一个数组
     * 这个函数的作用是求传入的数据中所有元素的和
     */
    Test2.prototype.Func6 = function (arg1) {
        //声明sum
        var sum = 0;
        //循环语句 执行顺序 (1)=>(2)=>(4)=>(3)=>(2)=>(4)=>(3)=>(2)=>(5)
        for ( /*(1)*/var i = 0; /*(2)*/ i < arg1.length; /*(3)*/ i++) {
            /*(4)*/
            //const -- 常数  作用跟let类似，区别是const的值在声明之后不允许修改
            var element = arg1[i];
            //求和
            sum = sum + element;
        }
        /*(5)*/
        //返回的关键字
        return sum;
    };
    /**
     * 这个函数的作用是求传入的数据中出了arg2元素之外的所有元素的和
     */
    Test2.prototype.Func7 = function (arg1, arg2) {
        var sum = 0;
        for (var i = 0; i < arg1.length; i++) {
            var element = arg1[i];
            //判断如果元素element等于arg2就退出"本次"循环
            if (element == arg2) {
                continue;
            }
            sum = sum + element;
        }
        //返回的关键字
        return sum;
    };
    /**
    * 求遇到arg2参数之前的参数的和
    */
    Test2.prototype.Func8 = function (arg1, arg2) {
        //var 的作用于let类似
        var sum = 0;
        for (var i = 0; i < arg1.length; i++) {
            var element = arg1[i];
            //判断如果元素element等于arg2就退出循环
            if (element == arg2) {
                break;
            }
            sum = sum + element;
        }
        //返回的关键字
        return sum;
    };
    Test2 = __decorate([
        ccclass
    ], Test2);
    return Test2;
}(cc.Component));
exports.default = Test2;

cc._RF.pop();