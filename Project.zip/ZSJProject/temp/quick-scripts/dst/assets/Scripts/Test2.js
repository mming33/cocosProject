
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Test2.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '32339/oKb9AII7J3yoVJFI8', 'Test2');
// Scripts/Test2.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Test2 = /** @class */ (function (_super) {
    __extends(Test2, _super);
    function Test2() {
        //这是一条注释
        //private -- 私有变量 public -- 公有变量  
        //区别就是私有变量只能在类内访问，共有变量可以在类外访问
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //这是一个数值的声明语句  typeScript 没有区分整型和浮点型统一用number来声明
        _this.a_number = 0;
        //这是一个字符串的声明语句
        _this.a_string = "";
        //这是一个布尔参数的声明语句
        _this.a_bool = true;
        //这是一个数组的声明语句
        _this.a_Array = new Array();
        _this.b_number = 0;
        _this.b_string = "";
        _this.b_bool = true;
        _this.b_Array = new Array();
        return _this;
        //关键字 var let const 
        //      break return continue
        //      for
        //      if else 
    }
    /**名称为Func1的无返回值的私有函数 */
    Test2.prototype.Func1 = function () {
    };
    /**名称为Func2的无返回值的共有函数 */
    Test2.prototype.Func2 = function () {
    };
    /**名称为Func3的无返回值的共有函数 */
    Test2.Func3 = function () {
    };
    /**名称为Func4的无返回值的共有函数
     * 在调用这个函数的时候需要传入两个参数 -- arg1,arg2
     * 这两个参数必须是数值类型
    */
    Test2.prototype.Func4 = function (arg1, arg2) {
    };
    /**名称为Func5的返回值是数值型的共有函数
     * 在调用这个函数的时候需要传入两个参数 -- arg1,arg2
     * 这两个参数必须是数值类型
    */
    Test2.prototype.Func5 = function (arg1, arg2) {
        //let 是在函数内部声明参数是用到的关键字 
        var sum = 0;
        //sum 的结果是arg1和arg2的和
        sum = arg1 + arg2;
        //返回的关键字
        return sum;
    };
    /**
     * 在调用这个函数的时候需要传入一个参数 -- arg1
     * 这个参数必须是一个数组
     * 这个函数的作用是求传入的数据中所有元素的和
     */
    Test2.prototype.Func6 = function (arg1) {
        //声明sum
        var sum = 0;
        //循环语句 执行顺序 (1)=>(2)=>(4)=>(3)=>(2)=>(4)=>(3)=>(2)=>(5)
        for ( /*(1)*/var i = 0; /*(2)*/ i < arg1.length; /*(3)*/ i++) {
            /*(4)*/
            //const -- 常数  作用跟let类似，区别是const的值在声明之后不允许修改
            var element = arg1[i];
            //求和
            sum = sum + element;
        }
        /*(5)*/
        //返回的关键字
        return sum;
    };
    /**
     * 这个函数的作用是求传入的数据中出了arg2元素之外的所有元素的和
     */
    Test2.prototype.Func7 = function (arg1, arg2) {
        var sum = 0;
        for (var i = 0; i < arg1.length; i++) {
            var element = arg1[i];
            //判断如果元素element等于arg2就退出"本次"循环
            if (element == arg2) {
                continue;
            }
            sum = sum + element;
        }
        //返回的关键字
        return sum;
    };
    /**
    * 求遇到arg2参数之前的参数的和
    */
    Test2.prototype.Func8 = function (arg1, arg2) {
        //var 的作用于let类似
        var sum = 0;
        for (var i = 0; i < arg1.length; i++) {
            var element = arg1[i];
            //判断如果元素element等于arg2就退出循环
            if (element == arg2) {
                break;
            }
            sum = sum + element;
        }
        //返回的关键字
        return sum;
    };
    Test2 = __decorate([
        ccclass
    ], Test2);
    return Test2;
}(cc.Component));
exports.default = Test2;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1Rlc3QyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsa0JBQXFDLEVBQW5DLG9CQUFPLEVBQUUsc0JBQTBCLENBQUM7QUFHNUM7SUFBbUMseUJBQVk7SUFEL0M7UUFFSSxRQUFRO1FBQ1Isa0NBQWtDO1FBQ2xDLDZCQUE2QjtRQUpqQyxxRUE0SEM7UUFySEcsZ0RBQWdEO1FBQ3hDLGNBQVEsR0FBVyxDQUFDLENBQUM7UUFDN0IsY0FBYztRQUNOLGNBQVEsR0FBVyxFQUFFLENBQUM7UUFDOUIsZUFBZTtRQUNQLFlBQU0sR0FBWSxJQUFJLENBQUM7UUFDL0IsYUFBYTtRQUNMLGFBQU8sR0FBa0IsSUFBSSxLQUFLLEVBQVUsQ0FBQztRQUU5QyxjQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLGNBQVEsR0FBVyxFQUFFLENBQUM7UUFDdEIsWUFBTSxHQUFZLElBQUksQ0FBQztRQUN2QixhQUFPLEdBQWtCLElBQUksS0FBSyxFQUFVLENBQUM7O1FBa0dwRCxvQkFBb0I7UUFDcEIsNkJBQTZCO1FBQzdCLFdBQVc7UUFDWCxnQkFBZ0I7SUFJcEIsQ0FBQztJQXZHRyx3QkFBd0I7SUFDaEIscUJBQUssR0FBYjtJQUVBLENBQUM7SUFFRCx3QkFBd0I7SUFDakIscUJBQUssR0FBWjtJQUVBLENBQUM7SUFDRCx3QkFBd0I7SUFDVixXQUFLLEdBQW5CO0lBRUEsQ0FBQztJQUVEOzs7TUFHRTtJQUNLLHFCQUFLLEdBQVosVUFBYSxJQUFZLEVBQUUsSUFBWTtJQUV2QyxDQUFDO0lBQ0Q7OztNQUdFO0lBQ0sscUJBQUssR0FBWixVQUFhLElBQVksRUFBRSxJQUFZO1FBQ25DLHdCQUF3QjtRQUN4QixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDWixxQkFBcUI7UUFDckIsR0FBRyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsUUFBUTtRQUNSLE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxxQkFBSyxHQUFaLFVBQWEsSUFBYztRQUN2QixPQUFPO1FBQ1AsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRVosdURBQXVEO1FBQ3ZELE1BQUssT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFBLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQSxDQUFDLEVBQUUsRUFBRTtZQUN2RCxPQUFPO1lBQ1AsNENBQTRDO1lBQzVDLElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixJQUFJO1lBQ0osR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUM7U0FDdkI7UUFDRCxPQUFPO1FBRVAsUUFBUTtRQUNSLE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQUdEOztPQUVHO0lBQ0kscUJBQUssR0FBWixVQUFhLElBQWMsRUFBRSxJQUFZO1FBQ3JDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNaLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xDLElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4Qiw4QkFBOEI7WUFDOUIsSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO2dCQUNqQixTQUFTO2FBQ1o7WUFDRCxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQztTQUN2QjtRQUNELFFBQVE7UUFDUixPQUFPLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFFRDs7TUFFRTtJQUNLLHFCQUFLLEdBQVosVUFBYSxJQUFjLEVBQUUsSUFBWTtRQUNyQyxlQUFlO1FBQ2YsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ1osS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbEMsSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hCLDBCQUEwQjtZQUMxQixJQUFJLE9BQU8sSUFBSSxJQUFJLEVBQUU7Z0JBQ2pCLE1BQU07YUFDVDtZQUNELEdBQUcsR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDO1NBQ3ZCO1FBQ0QsUUFBUTtRQUNSLE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQS9HZ0IsS0FBSztRQUR6QixPQUFPO09BQ2EsS0FBSyxDQTJIekI7SUFBRCxZQUFDO0NBM0hELEFBMkhDLENBM0hrQyxFQUFFLENBQUMsU0FBUyxHQTJIOUM7a0JBM0hvQixLQUFLIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRlc3QyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICAvL+i/meaYr+S4gOadoeazqOmHilxuICAgIC8vcHJpdmF0ZSAtLSDnp4HmnInlj5jph48gcHVibGljIC0tIOWFrOacieWPmOmHjyAgXG4gICAgLy/ljLrliKvlsLHmmK/np4HmnInlj5jph4/lj6rog73lnKjnsbvlhoXorr/pl67vvIzlhbHmnInlj5jph4/lj6/ku6XlnKjnsbvlpJborr/pl65cblxuXG4gICAgLy/ov5nmmK/kuIDkuKrmlbDlgLznmoTlo7DmmI7or63lj6UgIHR5cGVTY3JpcHQg5rKh5pyJ5Yy65YiG5pW05Z6L5ZKM5rWu54K55Z6L57uf5LiA55SobnVtYmVy5p2l5aOw5piOXG4gICAgcHJpdmF0ZSBhX251bWJlcjogbnVtYmVyID0gMDtcbiAgICAvL+i/meaYr+S4gOS4quWtl+espuS4sueahOWjsOaYjuivreWPpVxuICAgIHByaXZhdGUgYV9zdHJpbmc6IHN0cmluZyA9IFwiXCI7XG4gICAgLy/ov5nmmK/kuIDkuKrluIPlsJTlj4LmlbDnmoTlo7DmmI7or63lj6VcbiAgICBwcml2YXRlIGFfYm9vbDogYm9vbGVhbiA9IHRydWU7XG4gICAgLy/ov5nmmK/kuIDkuKrmlbDnu4TnmoTlo7DmmI7or63lj6VcbiAgICBwcml2YXRlIGFfQXJyYXk6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXk8bnVtYmVyPigpO1xuXG4gICAgcHVibGljIGJfbnVtYmVyOiBudW1iZXIgPSAwO1xuICAgIHB1YmxpYyBiX3N0cmluZzogc3RyaW5nID0gXCJcIjtcbiAgICBwdWJsaWMgYl9ib29sOiBib29sZWFuID0gdHJ1ZTtcbiAgICBwdWJsaWMgYl9BcnJheTogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheTxudW1iZXI+KCk7XG5cbiAgICAvKirlkI3np7DkuLpGdW5jMeeahOaXoOi/lOWbnuWAvOeahOengeacieWHveaVsCAqL1xuICAgIHByaXZhdGUgRnVuYzEoKTogdm9pZCB7XG5cbiAgICB9XG5cbiAgICAvKirlkI3np7DkuLpGdW5jMueahOaXoOi/lOWbnuWAvOeahOWFseacieWHveaVsCAqL1xuICAgIHB1YmxpYyBGdW5jMigpOiB2b2lkIHtcblxuICAgIH1cbiAgICAvKirlkI3np7DkuLpGdW5jM+eahOaXoOi/lOWbnuWAvOeahOWFseacieWHveaVsCAqL1xuICAgIHB1YmxpYyBzdGF0aWMgRnVuYzMoKTogdm9pZCB7XG5cbiAgICB9XG5cbiAgICAvKirlkI3np7DkuLpGdW5jNOeahOaXoOi/lOWbnuWAvOeahOWFseacieWHveaVsCBcbiAgICAgKiDlnKjosIPnlKjov5nkuKrlh73mlbDnmoTml7blgJnpnIDopoHkvKDlhaXkuKTkuKrlj4LmlbAgLS0gYXJnMSxhcmcyXG4gICAgICog6L+Z5Lik5Liq5Y+C5pWw5b+F6aG75piv5pWw5YC857G75Z6LXG4gICAgKi9cbiAgICBwdWJsaWMgRnVuYzQoYXJnMTogbnVtYmVyLCBhcmcyOiBudW1iZXIpOiB2b2lkIHtcblxuICAgIH1cbiAgICAvKirlkI3np7DkuLpGdW5jNeeahOi/lOWbnuWAvOaYr+aVsOWAvOWei+eahOWFseacieWHveaVsCBcbiAgICAgKiDlnKjosIPnlKjov5nkuKrlh73mlbDnmoTml7blgJnpnIDopoHkvKDlhaXkuKTkuKrlj4LmlbAgLS0gYXJnMSxhcmcyXG4gICAgICog6L+Z5Lik5Liq5Y+C5pWw5b+F6aG75piv5pWw5YC857G75Z6LXG4gICAgKi9cbiAgICBwdWJsaWMgRnVuYzUoYXJnMTogbnVtYmVyLCBhcmcyOiBudW1iZXIpOiBudW1iZXIge1xuICAgICAgICAvL2xldCDmmK/lnKjlh73mlbDlhoXpg6jlo7DmmI7lj4LmlbDmmK/nlKjliLDnmoTlhbPplK7lrZcgXG4gICAgICAgIGxldCBzdW0gPSAwO1xuICAgICAgICAvL3N1bSDnmoTnu5PmnpzmmK9hcmcx5ZKMYXJnMueahOWSjFxuICAgICAgICBzdW0gPSBhcmcxICsgYXJnMjtcbiAgICAgICAgLy/ov5Tlm57nmoTlhbPplK7lrZdcbiAgICAgICAgcmV0dXJuIHN1bTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDlnKjosIPnlKjov5nkuKrlh73mlbDnmoTml7blgJnpnIDopoHkvKDlhaXkuIDkuKrlj4LmlbAgLS0gYXJnMVxuICAgICAqIOi/meS4quWPguaVsOW/hemhu+aYr+S4gOS4quaVsOe7hFxuICAgICAqIOi/meS4quWHveaVsOeahOS9nOeUqOaYr+axguS8oOWFpeeahOaVsOaNruS4reaJgOacieWFg+e0oOeahOWSjFxuICAgICAqL1xuICAgIHB1YmxpYyBGdW5jNihhcmcxOiBudW1iZXJbXSk6IG51bWJlciB7XG4gICAgICAgIC8v5aOw5piOc3VtXG4gICAgICAgIGxldCBzdW0gPSAwO1xuXG4gICAgICAgIC8v5b6q546v6K+t5Y+lIOaJp+ihjOmhuuW6jyAoMSk9PigyKT0+KDQpPT4oMyk9PigyKT0+KDQpPT4oMyk9PigyKT0+KDUpXG4gICAgICAgIGZvciAoLyooMSkqL2xldCBpID0gMDsgLyooMikqL2kgPCBhcmcxLmxlbmd0aDsgLyooMykqL2krKykge1xuICAgICAgICAgICAgLyooNCkqL1xuICAgICAgICAgICAgLy9jb25zdCAtLSDluLjmlbAgIOS9nOeUqOi3n2xldOexu+S8vO+8jOWMuuWIq+aYr2NvbnN055qE5YC85Zyo5aOw5piO5LmL5ZCO5LiN5YWB6K645L+u5pS5XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gYXJnMVtpXTtcbiAgICAgICAgICAgIC8v5rGC5ZKMXG4gICAgICAgICAgICBzdW0gPSBzdW0gKyBlbGVtZW50O1xuICAgICAgICB9XG4gICAgICAgIC8qKDUpKi9cblxuICAgICAgICAvL+i/lOWbnueahOWFs+mUruWtl1xuICAgICAgICByZXR1cm4gc3VtO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICog6L+Z5Liq5Ye95pWw55qE5L2c55So5piv5rGC5Lyg5YWl55qE5pWw5o2u5Lit5Ye65LqGYXJnMuWFg+e0oOS5i+WklueahOaJgOacieWFg+e0oOeahOWSjCBcbiAgICAgKi9cbiAgICBwdWJsaWMgRnVuYzcoYXJnMTogbnVtYmVyW10sIGFyZzI6IG51bWJlcik6IG51bWJlciB7XG4gICAgICAgIGxldCBzdW0gPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFyZzEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSBhcmcxW2ldO1xuICAgICAgICAgICAgLy/liKTmlq3lpoLmnpzlhYPntKBlbGVtZW50562J5LqOYXJnMuWwsemAgOWHulwi5pys5qyhXCLlvqrnjq9cbiAgICAgICAgICAgIGlmIChlbGVtZW50ID09IGFyZzIpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1bSA9IHN1bSArIGVsZW1lbnQ7XG4gICAgICAgIH1cbiAgICAgICAgLy/ov5Tlm57nmoTlhbPplK7lrZdcbiAgICAgICAgcmV0dXJuIHN1bTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAqIOaxgumBh+WIsGFyZzLlj4LmlbDkuYvliY3nmoTlj4LmlbDnmoTlkoxcbiAgICAqL1xuICAgIHB1YmxpYyBGdW5jOChhcmcxOiBudW1iZXJbXSwgYXJnMjogbnVtYmVyKTogbnVtYmVyIHtcbiAgICAgICAgLy92YXIg55qE5L2c55So5LqObGV057G75Ly8XG4gICAgICAgIHZhciBzdW0gPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFyZzEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSBhcmcxW2ldO1xuICAgICAgICAgICAgLy/liKTmlq3lpoLmnpzlhYPntKBlbGVtZW50562J5LqOYXJnMuWwsemAgOWHuuW+queOr1xuICAgICAgICAgICAgaWYgKGVsZW1lbnQgPT0gYXJnMikge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3VtID0gc3VtICsgZWxlbWVudDtcbiAgICAgICAgfVxuICAgICAgICAvL+i/lOWbnueahOWFs+mUruWtl1xuICAgICAgICByZXR1cm4gc3VtO1xuICAgIH1cblxuXG5cblxuICAgIC8v5YWz6ZSu5a2XIHZhciBsZXQgY29uc3QgXG4gICAgLy8gICAgICBicmVhayByZXR1cm4gY29udGludWVcbiAgICAvLyAgICAgIGZvclxuICAgIC8vICAgICAgaWYgZWxzZSBcblxuXG5cbn1cbiJdfQ==